package com.project.Employeemngmt;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class EmployeemngmtApplicationTests {

	@Test
	void contextLoads() {
	}

}
