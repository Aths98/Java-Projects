package com.example.Task1;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Task1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
